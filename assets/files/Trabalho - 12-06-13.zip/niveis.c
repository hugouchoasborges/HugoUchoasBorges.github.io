/**
  * Joguinho RESTA 1
  * Feito por "Hugo Uch�as Borges - n�-27106 - ECO Unifei" ... favor n�o piratear ;)
  */

#include<stdio.h>

        /*  A difere�a entre cada  n�vel est� somente na Matriz que � declarada inicialmente para o jogo,
            al�m da pontua��o m�xima de cada n�vel ;)
        */





void nivel1(char m[7][7]){
int i,j;

    for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5))
                        m[i][j]='0';// Inicializa os termos da matriz que n�o fazem parte do tabuleiro com o valor 0
                    else
                        m[i][j]='2'; //Todos os outros termos restantes s�o inicializados com pe�as
            }
        }
                        m[3][3]='1';// tira a pe�a do centro do Tabuleiro

}









void nivel2(char m[7][7]){
int i,j;

    for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5))
                        m[i][j]='0';// Inicializa os termos da matriz que n�o fazem parte do tabuleiro com o valor 0
                    else
                        m[i][j]='2'; //Todos os outros termos restantes s�o inicializados com pe�a
            }
        }

                            //Todas as posi��es abaixo N�O TER�O PE�A
                        m[3][3]='1';
                        m[3][4]='1';
                        m[3][2]='1';
                        m[2][3]='1';
                        m[4][3]='1';
                        m[0][2]='1';
                        m[0][3]='1';
                        m[0][4]='1';
                        m[6][2]='1';
                        m[6][3]='1';
                        m[6][4]='1';
                        m[2][0]='1';
                        m[3][0]='1';
                        m[4][0]='1';
                        m[2][6]='1';
                        m[3][6]='1';
                        m[4][6]='1';

}









void nivel3(char m[7][7]){
int i,j;

    for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5))
                        m[i][j]='0';// Inicializa os termos da matriz que n�o fazem parte do tabuleiro com o valor 0
                    else
                        m[i][j]='1'; //Todos os outros termos restantes s�o inicializados SEM PE�A
            }
        }

                            //Todas as posi��es abaixo TER�O PE�A
                        m[0][3]='2';
                        m[1][3]='2';
                        m[2][3]='2';
                        m[4][3]='2';
                        m[5][3]='2';
                        m[6][3]='2';
                        m[4][0]='2';
                        m[4][1]='2';
                        m[4][2]='2';
                        m[4][4]='2';
                        m[4][5]='2';
                        m[4][6]='2';
                        m[3][1]='2';
                        m[3][2]='2';
                        m[3][4]='2';
                        m[3][5]='2';
                        m[2][2]='2';
                        m[2][4]='2';

}







void nivel4(char m[7][7]){
int i,j;

    for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5))
                        m[i][j]='0';// Inicializa os termos da matriz que n�o fazem parte do tabuleiro com o valor 0
                    else
                        m[i][j]='1'; //Todos os outros termos restantes s�o inicializados SEM PE�A
            }
        }

                            //Todas as posi��es abaixo TER�O PE�A
                        m[3][3]='2';
                        m[1][3]='2';
                        m[2][3]='2';
                        m[4][3]='2';
                        m[5][3]='2';
                        m[4][0]='2';
                        m[4][1]='2';
                        m[4][2]='2';
                        m[4][4]='2';
                        m[4][5]='2';
                        m[4][6]='2';
                        m[3][1]='2';
                        m[3][2]='2';
                        m[3][4]='2';
                        m[3][5]='2';
                        m[2][2]='2';
                        m[2][4]='2';

}










void nivel5(char m[7][7]){
int i,j;

    for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5))
                        m[i][j]='0';// Inicializa os termos da matriz que n�o fazem parte do tabuleiro com o valor 0
                    else
                        m[i][j]='2'; //Todos os outros termos restantes s�o inicializados com pe�a
            }
        }
                        m[2][2]='1'; //Posi��o [2][2] ser� a �nica Vazia

}
