/**
  * Joguinho RESTA 1
  * Feito por "Hugo Uch�as Borges - n�-27106 - ECO Unifei" ... favor n�o piratear ;)
  */

#include<stdio.h> //Biblioteca Padr�o
#include<conio.h> //Usarei para efeitos de cor
#include<string.h> //Tratamento de Strings
#include<windows.h> //Usarei para criar musicas para o jogo
#include "niveis.c" //Inclui o arquivo niveis.c e suas fun��es
#include<ctype.h> //Usarei apenas a fun��o toupper dessa biblioteca



typedef enum {nulo=48,vazio, cheio} pos; /*definindo um novo tipo de dado
                                          *para definir o status de cada posi��o do tabuleiro:
                                                *Nulo --> N�o faz parte do tabuleiro
                                                *Vazio --> N�o possui pe�a no local
                                                *Cheio --> Possui pe�a no local   */


void hud(int sel); /*Fun��o que mostra na  tela os poss�veis comandos para o usu�rio;
                    *Seu Par�metro apenas indica se uma pe�a j� est� atualmente selecionada ou n�o*/


void  inicializaVisual(char m[7][7]); // Inicializa a Matriz que ser� apresentada ao jogador;



void imprimeVisual(char m[7][7],int lin, int col,int opc,int lin2,int col2, char nivel); // Imprime a Matriz que ser� apresentada ao jogador;



void atualizaVisual(char m[7][7], char n[7][7]); // Atualiza a Matriz Visual de acordo com as modifica��es feitas na Matriz Tab


void verificaJogo(char visual[7][7]); //Verifica se ainda existem jogadas poss�veis para o jogo




// ------------------------------|| Fun��o Principal ||----------------------------------//

int main (int argc,char *argv[]){




    int i,j;
    int pntmax;          // Pontua��o m�xima necess�ria para cada n�vel
    char o[1];           //Um vetorzinho qualquer, pode ser �til (atualiza��o: foi �til)
    char nivel;          // Recebe o "nivel do jogo que ser� escolhido"
    int cont=0;          //Contador inicializado em 0
    int cont2=0;          //Contador inicializado em 0
    int sel=0;           //sel --> indica se o usu�rio est� "segurando" alguma pe�a - Padr�o: N�O
    int lin=3;           //lin --> linha atual em que o cursor est� colocado - Padr�o: 3
    int col=3;           //col --> coluna atual em que o cursor est� colocado - Padr�o: 3
    int pnt=0;           //pnt --> Pontua��o do usu�rio [10 pontos por cada pe�a comida]
    int lin2;            //linha marcada de uma pe�a selecionada
    int col2;            //coluna marcada de uma pe�a selecionada
    char com[1];         //com--> Comando dado pelo usu�rio
    char tab[7][7];      // Matriz do tabuleiro, serve para controlar o jogo;
    char visual[7][7];   // Matriz que ser� apresentada  ao jogador;

        nivel = argv[0]; // o valor de arg[0]  ser� utilizado para escolher o n�vel do jogo
        pntmax = argc; //argv ser� utilizado para definir a pontua��o m�xima do jogo

            if (nivel=='1'||nivel=='2'||nivel=='3'||nivel=='4'||nivel=='5'||nivel=='6'||nivel=='7') //Se o n�vel for um dos listados....
                goto JOGO;  // Ent�o ir� para JOGO, ou seja, pular� o Menu Principal;

                /* Aqui em cima, na primeira vez que executar MAIN, vai chamar o MENU().... o menu retornar� a chamar Main() para
                 * executar os n�veis. Quando isso acontecer, o main "pular�" o Menu()... usando "goto JOGO";  */


        menu(); //Chama o Menu do Jogo



            JOGO:
        clrscr(); //Limpa a tela

            if (nivel=='1') //Se o n�vel escolhido for 1
                nivel1(tab);             // Carrega o mapa nivel1
            if (nivel=='2') //Se o n�vel escolhido for 2
                nivel2(tab);             // Carrega o mapa nivel 2
            if (nivel=='3') //Se o n�vel escolhido for 3
                nivel3(tab);             // Carrega o mapa nivel 3
            if (nivel=='4') //Se o n�vel escolhido for 4
                nivel4(tab);             // Carrega o mapa nivel 4
            if (nivel=='5') //Se o n�vel escolhido for 5
                nivel5(tab);             // Carrega o mapa nivel 5
            if (nivel=='6') //Se o n�vel escolhido for 6
                nivelCustom(tab);             // Carrega "Level Creator"







        inicializaVisual(visual);       // Chama a fun��o inicializaVisual, tendo a matriz "visual" como par�metro
        atualizaVisual(tab,visual);     // Chama a fun��o atualizaVisual, tendo a matriz "tab" e a matriz "visual" como par�metros
        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);  // Chama a fun��o imprimeVisual, tendo a matriz "visual", e os inteiros "lin" , "col" e "sel" como par�metros
        hud(sel);                       //Chama a fun��o Hud... tendo o inteiro "sel" como par�metro



    do{

        gotoxy(20,13); // Move o cursor para o lado do HUD
            printf("Pontuacao: %d Pontos",pnt);


            verificaJogo(visual); //Verifica se existem jogadas possiveis



        com[0]=getch();  //Captura os comandos do jogador
        com[0] = toupper(com[0]); //Converte algarismo capturado para Mai�sculo

                switch(com[0]){

                    case 'D':           // Caso o jogador aperte 'D'
                        if ((col<6)&&(lin==2||lin==3||lin==4) || (col<4)&&(lin==0||lin==1||lin==5||lin==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite DIREITO do tabuleiro */
                            col++;  // A coluna selecionada se desloca para a DIREITA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);


                        }
                    break;



                    case 'A':           // Caso o jogador aperte 'a'
                        if ((col>0)&&(lin==2||lin==3||lin==4) || (col>2)&&(lin==0||lin==1||lin==5||lin==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite ESQUERDO do tabuleiro*/
                            col--;  // A coluna selecionada se desloca para a ESQUERDA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                        }
                    break;



                    case 'W':           // Caso o jogador aperte 'w'
                        if ((lin>0)&&(col==2||col==3||col==4) || (lin>2)&&(col==0||col==1||col==5||col==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite MAIS ALTO do tabuleiro*/
                            lin--;  // A linha selecionada se desloca para CIMA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                        }
                    break;



                    case 'S':           // Caso o jogador aperte 's'
                        if ((lin<6)&&(col==2||col==3||col==4) || (lin<4)&&(col==0||col==1||col==5||col==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite MAIS BAIXO do tabuleiro*/
                            lin++;  // A linha selecionada se desloca para BAIXO
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                        }
                    break;


                    case 'F': //Caso o jogador aperte 'f'

                       if (sel==0){ //Se o jogador n�o estiver segurando a pe�a

                            if (tab[lin][col]==cheio){ // E se a posi��o no tabuleiro estiver ocupada

                                sel=1; // O jogador passa a segurar a pe�a
                                    lin2=lin;  //a posi��o "lin" ser� marcada na vari�vel "lin2" ... indica a linha em que a pe�a est� selecionada
                                    col2=col;  //a posi��o "col" ser� marcada na vari�vel "col2" ... indica a coluna em que a pe�a est� selecionada
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                            }

                       }

                       else{  // Ou seja,  se o jogador estiver segurando a Pe�a

                            if (tab[lin][col]==cheio){ //Se a posi��o em que o usu�rio estiver tentando soltar a pe�a estiver cheia... ent�o

                                sel=0; // O jogador Solta a pe�a  - MAS N�O MUDA NADA NO JOGO;
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                            }


                            if (tab[lin][col]==vazio){ // Se a posi��o no tabuleiro estiver Vazia

                                   if ((col==col2)&&((lin2==(lin)-2))&&(tab[lin-1][col]==cheio)){ /* Se a coluna de onde a pe�a for retirada for
                                                                        * igual � coluna onde o usu�rio est� tentando colocar a pe�a.
                                                                        * E se a linha retirada for duas posi��es ACIMA de onde
                                                                        * o usu�rio est� tentando coloc�-la.
                                                                        * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                        sel=0; // O usu�rio soltar� a pe�a;
                                        comerPeca(); //Som para comer pe�as

                                        tab[lin-2][col]=vazio;  // A coluna onde a pe�a estava ficar� vazia
                                        tab[lin-1][col]=vazio; //A coluna entre as duas ficar� vazia
                                        tab[lin][col]=cheio; //A coluna de destino receber� uma pe�a.

                                            pnt+=10; // O usu�rio ganhar� 10 pontos
                                                if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                goto FIM2;       //respectivel n�vel , finalize o jogo com o Final 2*/


                                    }


                                    if ((col==col2)&&((lin2==(lin)+2))&&(tab[lin+1][col]==cheio)){ /* Se a coluna de onde a pe�a for retirada for
                                                                        * igual � coluna onde o usu�rio est� tentando colocar a pe�a.
                                                                        * E se a linha retirada for duas posi��es ABAIXO de onde
                                                                        * o usu�rio est� tentando coloc�-la.
                                                                        * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                        sel=0; // O usu�rio soltar� a pe�a;
                                        comerPeca(); //Som para comer pe�as


                                        tab[lin+2][col]=vazio;  // A coluna onde a pe�a estava ficar� vazia
                                        tab[lin+1][col]=vazio; //A coluna entre as duas ficar� vazia
                                        tab[lin][col]=cheio; //A coluna de destino receber� uma pe�a.


                                            pnt+=10; // O usu�rio ganhar� 10 pontos
                                            if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                    goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2


                                    }


                                    if ((lin==lin2)&&((col2==(col)+2))&&(tab[lin][col+1]==cheio)){ /* Se a linha de onde a pe�a for retirada for
                                                                        * igual � linha onde o usu�rio est� tentando colocar a pe�a.
                                                                        * E se a coluna retirada for duas posi��es � DIREITA de onde
                                                                        * o usu�rio est� tentando coloc�-la.
                                                                        * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                        sel=0; // O usu�rio soltar� a pe�a;
                                        comerPeca(); //Som para comer pe�as

                                        tab[lin][col+2]=vazio;  // A coluna onde a pe�a estava ficar� vazia
                                        tab[lin][col+1]=vazio; //A coluna entre as duas ficar� vazia
                                        tab[lin][col]=cheio; //A coluna de destino receber� uma pe�a.


                                            pnt+=10; // O usu�rio ganhar� 10 pontos
                                            if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                    goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2*/


                                    }


                                    if ((lin==lin2)&&((col2==(col)-2))&&(tab[lin][col-1]==cheio)){ /* Se a linha de onde a pe�a for retirada for
                                                                        * igual � linha onde o usu�rio est� tentando colocar a pe�a.
                                                                        * E se a coluna retirada for duas posi��es � ESQUERDA de onde
                                                                        * o usu�rio est� tentando coloc�-la.
                                                                        * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                        sel=0; // O usu�rio soltar� a pe�a;
                                        comerPeca(); //Som para comer pe�as

                                        tab[lin][col-2]=vazio;  // A coluna onde a pe�a estava ficar� vazia
                                        tab[lin][col-1]=vazio; //A coluna entre as duas ficar� vazia
                                        tab[lin][col]=cheio; //A coluna de destino receber� uma pe�a.


                                            pnt+=10; // O usu�rio ganhar� 10 pontos
                                            if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                    goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2*/


                                    }

                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,imprimeVisual);
                                        hud(sel);

                            }
                       }

                    break;




                    case 'X': //Caso o jogador aperte 'x'
                        do{
                                    gotoxy(20,14);
                                    printf("                                                                 ");
                                    gotoxy(20,14);
                                    printf("Deseja: Sair(1) || Voltar para o Menu(2) ");
                                        o[0]=getch(); //Captura de teclas
                                                switch(o[0]){
                                                    case '1': //Caso o jogador aperte 1
                                                        gotoxy(20,25);
                                                        goto FIM; //Vai para o processo de finaliza��o do jogo

                                                    break;

                                                    case '2': //Caso o jogador aperte 2
                                                        clrscr(); //Limpa a tela e
                                                         menu(); //Volta para o Menu Principal
                                                    break;

                                                    default:
                                                        gotoxy(20,14);
                                                        printf("                                                 "); //Serve para limpar a linha atual
                                                    break;
                                                    }
                        }while(1==1); //Sempre se repetir�, a menos que alguma fun��o quebre o looping
                    break;

                    default: //Qualquer outro bot�o apertado
                    break;


                }
    }while(1==1);



    FIM: //Processo de Finaliza��o 1 do jogo..... usado para se o jogador DESISTIR da partida
        gotoxy(1,23);
            textcolor(12);
                printf("                       FIM DE JOGO\n");
            textcolor(2);
                printf("                     Voce fez:");
            textcolor(15);
                printf(" %d Pontos",pnt); //Exibe a pontua��o do Usu�rio

        gotoxy(1,25); //Simplesmente coloca o "process returned...." no final do programa

    puts("\n");
    sairJogo(); //M�sica quando o jogador desiste de uma partida
    system("pause");


        exit(0); //Encerra o jogo


FIM2: //Processo de Finaliza��o 2 do jogo ...... usado para se o jogador VENCER a partida
    clrscr(); // Limpa a Tela
    atualizaVisual(tab,visual);
    imprimeVisual(visual,lin,col,sel,lin2,col2,visual);
    hud(sel);


    gotoxy(1,23);
            textcolor(13);
                printf("                       FIM DE JOGO\n");
            textcolor(2);
                printf("             Voce fez:");
            textcolor(15);
                printf(" %d Pontos .... PONTUACAO MAXIMA",pnt);
            musicaVitoria(); //M�sica quando o jogador vence

        gotoxy(1,25); //Simplesmente coloca o "process returned...." no final do programa, pois acho feio isso

    puts("\n");
    system("pause");




return 0;
}

//----------------------------------------------------------------------------------------//




//------------------------------|| HUD ||-----------------------------//

void hud(int sel){
    char f[20];

        if (sel==0)                     //Se o jogador n�o estiver segurando nenhuma pe�a
                strcpy(f,"Escolher ");     //o HUD mostrar� a op��o para pegar uma pe�a.
        else                            //Caso contr�rio,
                strcpy(f,"Soltar   ");     //o jogo jogo ter� a op��o de soltar a pe�a atual




                gotoxy(1,10); //move o cursor para debaixo do Tabuleiro, onde ser� impresso o HUD

            puts("\n\n ________________");
            printf("|");

                textcolor(12);          //Muda os pr�ximos textos para a cor vermelha
           printf("--> COMANDOS <--");
                textcolor(15);          //Retorna os pr�ximos textos para a cor branca


            puts("|");
            puts("|________________|");
            puts("|                |");
            puts("| W  -  Cima     |");
            puts("| S  -  Baixo    |");
            puts("| A  -  Esquerda |");
            puts("| D  -  Direita  |");
            printf("| F  -  ");


                if(sel==0){
                    textcolor(12);//Texto vermelho
                        printf("%s",f);   //f � uma vari�vel que imprime se o usu�rio est� segurando ou n�o uma pe�a
                    textcolor(15);//Texto Branco
                }

                if(sel==1){
                    textcolor(10); //Texto Verde
                        printf("%s",f);   //f � uma vari�vel que imprime se o usu�rio est� segurando ou n�o uma pe�a
                    textcolor(15);//Texto Branco
                }

                /* Aqui em cima eu basicamente fiz com que, se o usu�rio estiver segurando uma pe�a... o texto ficar� verde
                 *  e caso contr�rio, o texto ficar� vermelho   */



            printf("|\n");
            puts("| X  -  Sair     |");

            puts("|________________|");
}

//----------------------------------------------------------------------------------------//





// ------------------------------|| Inicializando a Matriz Visual (exibida para o jogador)||-----------------------------//

void inicializaVisual(char m[7][7]){
    int i,j;

        for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                m[i][j]=48;         //Inicializa todos os termos do tabuleiro com '0'  (que ser� o termo nulo do meu jogo)
            }
        }


}

//----------------------------------------------------------------------------------------------------------------------//



// ------------------------------------|| Atualizando a Matriz Visual ||------------------------------------------------//

void atualizaVisual(char m[7][7],char n[7][7]){
    int i,j;

    for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                n[i][j]=m[i][j];  //Copia o conte�do da matriz "tab" para a Matriz "visual"

                    if(n[i][j]==cheio) // Se a posi��o estiver cheia, insere um 'o' no local para representar uma pe�a
                        n[i][j]='o';
                    if(n[i][j]==vazio) // Se estiver vazia, insere um espa�o para indicar que est� vazia
                        n[i][j]=' ';
                    if(n[i][j]==nulo) // Se estiver vazia, insere um espa�o Tamb�m
                        n[i][j]=' ';
            }
        }

}

//----------------------------------------------------------------------------------------------------------------------//






// ------------------------------|| Imprimindo a Matriz Visual ||--------------------------//

void imprimeVisual(char m[7][7],int lin,int col,int opc,int lin2, int col2, char nivel){
    int i,j,h;


            printf("             |");

            textbackground(15); //Muda a cor do fundo para branco
            textcolor(0); //Muda a cor do texto para preto

                        printf("       ------| RESTA 1 |------    "); //T�tulo do jogo

            textcolor(15); // Volta o texto para a cor Branca
            textbackground(0);  // Volta o fundo para a  cor preta




    printf("|\n             |                                  |\n             |    ");


        for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5)){ /*Exce��o que distingue os cantos in�teis do
                                                                                                         *tabuleiro de seu centro na matriz */
                        m[i][j]=' ';   /*Todos os elementos da Matriz que n�o pertencem ao
                                        * tabuleiro receber�o ' ' como valor */
                            printf(" %c  ",m[i][j]);
                    }else
                        printf("[%c] ",m[i][j]); // Coloca os valores do tabuleiro entre colchetes, para melhor representa��o

            }
            printf("  |\n             |    ");
        }
        delline(); //Deleta a linha atual
        gotoxy(1,10); //Manda o cursor para a coluna 1 da linha 0
        printf("             |__________________________________|");


                gotoxy(15,10); //Manda o cursor para a linha 10, coluna 15

                    if(nivel=='1'){
                            textcolor(10);                  // Muda a cor do texto para Verde
                                printf("Nivel 1");
                            textcolor(15);                  // Muda a cor do texto de volta para Branco
                    }

                    if(nivel=='2'){
                            printf("______");
                            textcolor(6);                  // Muda a cor do texto para Verde
                                printf("Nivel 2");
                            textcolor(15);                  // Muda a cor do texto de volta para Branco
                    }

                    if(nivel=='3'){
                            printf("____________");
                            textcolor(12);                  // Muda a cor do texto para Verde
                                printf("Nivel 3");
                            textcolor(15);                  // Muda a cor do texto de volta para Branco
                    }

                    if(nivel=='4'){
                            printf("___________________");
                            textcolor(14);                  // Muda a cor do texto para Verde
                                printf("Nivel 4");
                            textcolor(15);                  // Muda a cor do texto de volta para Branco
                    }

                    if(nivel=='5'){
                            printf("_________________________");
                            textcolor(2);                  // Muda a cor do texto para Verde
                                printf("Nivel 5");
                            textcolor(15);                  // Muda a cor do texto de volta para Branco
                    }
                    if(nivel=='7'){
                            textcolor(2);                  // Muda a cor do texto para Verde
                                printf("CUSTOM");
                            textcolor(15);                  // Muda a cor do texto de volta para Branco
                    }



                    if (opc==0){    // Se o usu�rio n�o estiver "segurando" uma pe�a, ent�o...
                            textcolor(15);      // Muda a cor do texto para AZUL

                                    gotoxy(19+((col2*4)),3+lin2); //Posiciona o cursor no primeiro colchete da posi��o onde uma pe�a estava  sendo segurada
                                        printf("[");  //Substitui o abre-colchete atual por um outro BRANCO
                                    gotoxy(21+((col2*4)),3+lin2); //Posiciona o cursor no segundo colchete da posi��o onde uma pe�a estava  sendo segurada
                                        printf("]"); //Substitui o fecha-colchete atual por um outro BRANCO

                            textcolor(15);     // Muda a cor do texto de volta para Branco
                    }


                                                if (opc==0)    // Se o usu�rio n�o estiver "segurando" uma pe�a, ent�o...
                                                        textcolor(12);      // Muda a cor do texto para Vermelho
                                                if (opc==1)//Caso contr�rio, ou seja, ele esteja segurando uma pe�a
                                                        textcolor(10);      // Muda a cor do texto para Verde

                                                                gotoxy(19+((col*4)),3+lin); //Posiciona o cursor no primeiro colchete de alguma posi��o do tabuleiro
                                                                    printf("[");  //Substitui o abre-colchete atual por um outro COLORIDO
                                                                gotoxy(21+((col*4)),3+lin); //Posiciona o cursor no segundo colchete de alguma posi��o do tabuleiro
                                                                    printf("]"); //Substitui o fecha-colchete atual por um outro COLORIDO

                                                        textcolor(15);     // Muda a cor do texto de volta para Branco

                                                        /* Aqui em cima eu basicamente pintei os colchetes da posi��o onde o cursor estiver
                                                         *, utilizando Verde caso o usu�rio esteja segurando uma pe�a, e Vermelho caso contr�rio */





                    if (opc==1){  //Caso contr�rio, ou seja, ele esteja segurando uma pe�a
                            textcolor(11);      // Muda a cor do texto para AZUL
                                    gotoxy(19+((col2*4)),3+lin2); //Posiciona o cursor no primeiro colchete da posi��o de uma pe�a que est� sendo segurada
                                        printf("[");  //Substitui o abre-colchete atual por um outro AZUL
                                    gotoxy(21+((col2*4)),3+lin2); //Posiciona o cursor no segundo colchete de uma pe�a que est� sendo segurada
                                        printf("]"); //Substitui o fecha-colchete atual por um outro AZUL

                            textcolor(15);     // Muda a cor do texto de volta para BRANCO

                    }





}

//--------------------------------------------------------------------------------------------------------------------//




//---------------------------------||    Verificar jogadas poss�veis   ||----------------------------------------------//

void verificaJogo(char visual[7][7]){ //Fiz todas as condi��es manualmente para n�o correr nenhum risco de errar...
    int i,j,cont=0,k,l;

        for(i=0;i<7;i++){
            for(j=0;j<7;j++){
                if(((i>=0&&i<2)&&(j==0||j==1||j==6||j==5)) || ((i<7&&i>4)&&(j==0||j==1||j==6||j==5))){ /*Limita apenas para
                                                                                                    * Posi��es fora do Tabuleiro*/
                        cont++;
                }else{
                        if(visual[i][j]==' '){
                            cont++;

                        }else if(visual[i][j]=='o'){

                                if(i==0&&j==2){
                                    if((visual[0][3]=='o'&&visual[0][4]=='o'&&visual[1][2]==' ')||(visual[0][3]==' '&&visual[1][2]==' '))
                                        cont++;
                                }
                                if(i==0&&j==3){
                                    if((visual[0][2]=='o'&&visual[0][4]=='o'&&visual[1][3]==' ')||(visual[0][4]==' '&&visual[1][3]==' '&&visual[0][2]==' '))
                                        cont++;
                                }
                                if(i==0&&j==4){
                                    if((visual[0][3]=='o'&&visual[0][2]=='o'&&visual[1][4]==' ')||(visual[0][3]==' '&&visual[1][4]==' '))
                                        cont++;
                                }
                                if(i==1&&j==2){
                                    if((visual[1][3]=='o'&&visual[1][4]=='o'&&visual[0][2]==' '&&visual[2][2]==' ')||(visual[1][3]==' '&&visual[0][2]==' '&&visual[2][2]))
                                        cont++;
                                }
                                if(i==1&&j==3){
                                    if((visual[1][2]=='o'&&visual[1][4]=='o'&&visual[0][3]==' '&&visual[2][3]==' ')||(visual[1][4]==' '&&visual[1][2]==' '&&visual[0][3]==' '&&visual[2][3]==' '))
                                        cont++;
                                }
                                if(i==1&&j==4){
                                    if((visual[1][3]=='o'&&visual[1][2]=='o'&&visual[0][4]==' '&&visual[2][4]==' ')||(visual[0][4]==' '&&visual[2][4]==' '&&visual[1][3]==' '))
                                        cont++;
                                }




                                if(i==6&&j==2){
                                    if((visual[6][3]=='o'&&visual[6][4]=='o'&&visual[5][2]==' ')||(visual[6][3]==' '&&visual[5][2]==' '))
                                        cont++;
                                }
                                if(i==6&&j==3){
                                    if((visual[6][2]=='o'&&visual[6][4]=='o'&&visual[5][3]==' ')||(visual[6][4]==' '&&visual[5][3]==' '&&visual[6][2]==' '))
                                        cont++;
                                }
                                if(i==6&&j==4){
                                    if((visual[6][3]=='o'&&visual[6][2]=='o'&&visual[5][4]==' ')||(visual[6][3]==' '&&visual[5][4]==' '))
                                        cont++;
                                }
                                if(i==5&&j==2){
                                    if((visual[5][3]=='o'&&visual[5][4]=='o'&&visual[6][2]==' '&&visual[4][2]==' ')||(visual[5][3]==' '&&visual[4][2]==' '&&visual[6][2]))
                                        cont++;
                                }
                                if(i==5&&j==3){
                                    if((visual[5][2]=='o'&&visual[5][4]=='o'&&visual[6][3]==' '&&visual[4][3]==' ')||(visual[5][4]==' '&&visual[5][2]==' '&&visual[4][3]==' '&&visual[6][3]==' '))
                                        cont++;
                                }
                                if(i==5&&j==4){
                                    if((visual[5][3]=='o'&&visual[5][2]=='o'&&visual[6][4]==' '&&visual[4][4]==' ')||(visual[6][4]==' '&&visual[4][4]==' '&&visual[5][3]==' '))
                                        cont++;
                                }







                                if(j==0&&i==2){
                                    if((visual[3][0]=='o'&&visual[4][0]=='o'&&visual[2][1]==' ')||(visual[3][0]==' '&&visual[2][1]==' '))
                                        cont++;
                                }
                                if(j==0&&i==3){
                                    if((visual[2][0]=='o'&&visual[4][0]=='o'&&visual[3][1]==' ')||(visual[4][0]==' '&&visual[3][2]==' '&&visual[2][0]==' '))
                                        cont++;
                                }
                                if(j==0&&i==4){
                                    if((visual[3][0]=='o'&&visual[2][0]=='o'&&visual[4][1]==' ')||(visual[3][0]==' '&&visual[4][1]==' '))
                                        cont++;
                                }
                                if(j==1&&i==2){
                                    if((visual[3][1]=='o'&&visual[4][1]=='o'&&visual[2][0]==' '&&visual[2][2]==' ')||(visual[3][1]==' '&&visual[2][0]==' '&&visual[2][2]))
                                        cont++;
                                }
                                if(j==1&&i==3){
                                    if((visual[2][1]=='o'&&visual[4][1]=='o'&&visual[3][0]==' '&&visual[3][2]==' ')||(visual[4][1]==' '&&visual[2][1]==' '&&visual[3][0]==' '&&visual[3][2]==' '))
                                        cont++;
                                }
                                if(j==1&&i==4){
                                    if((visual[3][1]=='o'&&visual[2][1]=='o'&&visual[4][0]==' '&&visual[4][2]==' ')||(visual[4][0]==' '&&visual[4][2]==' '&&visual[3][1]==' '))
                                        cont++;
                                }




                                if(j==6&&i==2){
                                    if((visual[3][6]=='o'&&visual[4][6]=='o'&&visual[2][5]==' ')||(visual[3][6]==' '&&visual[5][2]==' '))
                                        cont++;
                                }
                                if(j==6&&i==3){
                                    if((visual[2][6]=='o'&&visual[4][6]=='o'&&visual[3][5]==' ')||(visual[4][6]==' '&&visual[5][3]==' '&&visual[6][2]==' '))
                                        cont++;
                                }
                                if(j==6&&i==4){
                                    if((visual[3][6]=='o'&&visual[2][6]=='o'&&visual[4][5]==' ')||(visual[3][6]==' '&&visual[5][4]==' '))
                                        cont++;
                                }
                                if(j==5&&i==2){
                                    if((visual[3][5]=='o'&&visual[4][5]=='o'&&visual[2][6]==' '&&visual[2][4]==' ')||(visual[3][5]==' '&&visual[2][4]==' '&&visual[2][6]))
                                        cont++;
                                }
                                if(j==5&&i==3){
                                    if((visual[2][5]=='o'&&visual[4][5]=='o'&&visual[3][6]==' '&&visual[3][4]==' ')||(visual[4][5]==' '&&visual[2][5]==' '&&visual[3][4]==' '&&visual[3][6]==' '))
                                        cont++;
                                }
                                if(j==5&&i==4){
                                    if((visual[3][5]=='o'&&visual[2][5]=='o'&&visual[4][6]==' '&&visual[4][4]==' ')||(visual[4][6]==' '&&visual[4][4]==' '&&visual[3][5]==' '))
                                        cont++;
                                }




                                    if(i==2&&j==2){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==3&&j==3){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==4&&j==4){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }

                                    if(i==2&&j==3){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==2&&j==4){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==3&&j==2){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==3&&j==4){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==4&&j==2){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }
                                    if(i==4&&j==3){
                                        if(visual[i-1][j]==' '&&visual[i][j-1]==' '&&visual[i+1][j]==' '&&visual[i][j+1]==' '){
                                            cont++;
                                        }

                                    }


                        }



                }
            }

        }



        if(cont==49){
                gotoxy(20,14); // Move o cursor para o lado do HUD
                    textcolor(10);
                        printf("Parece que voce si ferrou, aperte X para sair do jogo");
                gotoxy(39,14);
                    textcolor(12);
                        printf("FERROU");
                    textcolor(15);
                    perderJogo();
        }




}


















