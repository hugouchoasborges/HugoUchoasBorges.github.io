        /**
  * Joguinho RESTA 1
  * Feito por "Hugo Uch�as Borges - n�-27106 - ECO Unifei" ... favor n�o piratear ;)
  */


#include "resta1.c" //Programa do jogo em s�
#include "song.c"  //Criei esse arquivo para facilitar a cria��o de m�sicas
#include "custom.c"  //� basicamente um "Level Creator"
#include <ctype.h>


//Fun��es Utilizadas:
        /* void titulo(); --> Imprime um T�tulo para o jogo usando 'desenhos' em asc, com uma "pausa" entre o desenho de cada elemento
        * void tempo(int valor); --> Apenas uma fun��o com o mesmo valor da fun��o "sleep()" .... pois est� funcionando sleep() N�o sei porque;
        * void titulo2(); --> Imprime o mesmo T�tulo, por�m instantaneamente
        * void hudMenu(int lin); --> Menu de op��es do Menu, recebe como param�tro lin, que indica qual linha est� selecionada
        * void hudOpc(); --> Mostra as op��es de Comandos dispon�veis para o jogador
        * void novoJogo(int lin); --> Entra no Menu "Novo Jogo"
        * void easter(); -->  Um pequeno easter egg :P
        * void singlePlayer(int lin);    --> Entra no menu "singlePlayer"... lin � um par�metro que mostra qual linha est� selecionada
        * void custom();   --> Mini-game em que o usu�rio cria sua pr�pria fase
        */



// ----------------------------|| Menu Principal ||-----------------------------//

void menu(){
    char o[1]; //Um caracter qualquer, pode ser que eu precise em algum momento :)
    int lin = 1; //Inicializa lin com o valor 1, indicando que o Menu come�a com a 1� linha selecionada
    char opc[1]; // "opc" ler� os comandos do jogador dentro do MENU

    titulo();  //Desenha  o T�tulo metodicamente
    hudMenu(lin);

    do{
        opc[0]=getch();  //Captura o teclado do usu�rio
        opc[0] = toupper(opc[0]); //Converte algarismo para Mai�sculo
            switch (opc[0]){

                    case 'W':  //Caso o usu�rio tecle 'W'

                            if(lin>1){ //E se a linha selecionada for maior que 1
                                lin--;  // A linha selecionada passa para cima
                                moverMenu();
                            }
                    break;

                    case 'S': //Caso o usu�rio tecle 'S'

                            if(lin<3){ //E se a linha selecionada for maior que 1
                                lin++;  // A linha selecionada passa para cima
                                moverMenu();
                            }
                    break;

                    case 'F': //Caso o usu�rio tecle 'F'

                            if(lin==1){ //Se a 1� linha estiver selecionada
                                escolherMenu();
                                novoJogo(lin); //Entra no Menu "Novo Jogo"

                            }


                            if(lin==2){ //Se a 2� linha estiver selecionada
                                escolherMenu();
                                clrscr();
                                    titulo2(); //Desenha o T�tulo, por�m instantaneamente
                                        printf("\n\n\n\n      Compre a versao Completa do jogo para habilitar SaveGames ;)\n\n      ");

                                        textcolor(14);  //Texto na cor amarela
                                        printf("\n\n\n\nAperte qualquer tecla para voltar ao menu anterior...\n");
                                        textcolor(15); //Texto na cor branca
                                            getch(); //Captura um caracter do teclado
                                                clrscr(); //Limpa a tela
                                                menu(); //Chama o Menu Principal
                            }


                            if(lin==3){ //Se a 3� linha estiver selecionada
                                    escolherMenu();
                                printf("\n");
                                    textcolor(14);
                                    printf("                 Obrigado por testar o meu jogo :)\n\n");
                                    textcolor(15);
                                system("pause");
                                exit(0);  //O jogo � encerrado
                            }

                    break;

                    default: //Caso Padr�o
                    break;
            }
        clrscr(); // Limpa a Tela
        titulo2(); //Chama o Titulo 2  (T�tulo impresso instantaneamente)
        hudMenu(lin); //Chama o hud do MENU

    }while(1==1); //Ou seja, repetir� isso eternamente, ou at� o jogo ser encerrado por um comando que quebre esse looping

}

// --------------------------------------------------------------------------------//







// ----------------------------|| Menu "NOVO JOGO" ||-----------------------------//

void novoJogo(int lin){
    char op[1];  //Entrada de comando do usu�rio

                clrscr();
                titulo2(); //Chama o T�tulo 2... que � o mesmo do 1, por�m escrito sem um "Delay"
                printf("\n");

                textcolor(12); //Muda o texto para Vermelho
                    printf("                -----------> MENU <-----------\n\n                      ");
                textcolor(15); //Muda o texto para Branco

                    printf("  ");
                if (lin==1){    //Se a linha 1 estiver selecionada
                        textcolor(0);    //Muda o texto para Preto
                        textbackground(15);  //Muda o fundo para branco
                            printf("SinglePlayer");
                        textcolor(15);  //Muda o texto para Vermelho
                        textbackground(0);  //Muda o Fundo para preto
                }else
                    printf("Singleplayer");
                    printf("\n                        ");

                if (lin==2){  //Se a linha 2 estive selecionada
                        textcolor(0);  //Muda o Texto para preto
                        textbackground(15);  //Muda o Fundo para Branco
                            printf("Multiplayer");
                        textcolor(15); //Muda o texto para branco
                        textbackground(0); //Muda o Fundo para preto
                }else{
                    textcolor(7);
                        printf("Multiplayer");
                    textcolor(15);
                }
                printf("\n                           ");

                if (lin==3){
                        textcolor(0);//Muda o texto para preto
                        textbackground(15); //Muda o Fundo para  branco
                            printf("Voltar");
                        textcolor(15);
                        textbackground(0);
                }else
                    printf("Voltar");
                    printf("\n                       ");

    hudOpc();

    do{

        op[0]=getch(); //Comando do usu�rio
        op[0] = toupper(op[0]); //Converte algarismo para Mai�sculo
            switch (op[0]){


                case 'W':  //Caso o usu�rio aperte 'W'
                    if(lin>1){  //Se a linha n�o estiver no  topo
                        lin--; //Sobe a linha
                        moverMenu();
                    }
                break;

                case 'S':  //Caso o usu�rio aperte 'S'
                    if(lin<3){  //Se a linha n�o estiver no local mais baixo
                        lin++; //Desce a linha
                            moverMenu();
                    }
                break;

                case 'F':  //Caso o usu�rio aperte 'F'

                        if (lin==1){ //Se a linha 2 estiver selecionada
                                escolherMenu();
                            clrscr();
                                singlePlayer(lin); //Entra o Menu SinglePlayer
                        }


                        if (lin==2){ //Se a linha 2 estiver selecionada
                                escolherMenu();
                            clrscr();
                                easter(); //Entra no modo "Multiplayer"... que na verdade n�o existe
                        }


                        if (lin==3){ //Se a linha 3 estiver selecionada
                                escolherMenu();
                            clrscr();
                            menu(); //Saia do jogo
                        }


                break;


                default:
                break;

            }

            novoJogo(lin); //Chama novamente o menu NovoJogo()
        }while(1==1); //Infinitamente... ou at� alguma quebra de looping

system("pause"); //Pausa o jogo.... mas isso nunca ser� usado.... usei apenas durante o desenvolvimento;
}

// --------------------------------------------------------------------------------//




// ----------------------------|| Mostra as op��es do MENU ||-----------------------------//

void  hudMenu(int lin){
    printf("\n");


        textcolor(12);
            printf("                -----------> MENU <-----------\n\n                      ");
        textcolor(15);


        if (lin==1){
                textcolor(0);
                textbackground(15);
                    printf("Iniciar Novo Jogo");
                textcolor(15);
                textbackground(0);
        }else
            printf("Iniciar Novo Jogo");
            printf("\n                       ");

        if (lin==2){
                textcolor(0);
                textbackground(15);
                    printf("Continuar Jogo");
                textcolor(15);
                textbackground(0);
        }else{
            textcolor(7);
                printf("Continuar Jogo");
            textcolor(15);
        }
        printf("\n                            ");

        if (lin==3){
                textcolor(0);
                textbackground(15);
                    printf("Sair");
                textcolor(15);
                textbackground(0);
        }else
            printf("Sair");
            printf("\n                       ");



    hudOpc(); //Chama o HUD com op��es para o jogador

}


// -------------------------------------------------------------------------------------------//






// ----------------------------|| Mostra as teclas dispon�veis: ||-----------------------------//

void hudOpc(){
    char f[20]; //N�o ser� usado....


                gotoxy(1,15); //move o cursor para debaixo do Tabuleiro, onde ser� impresso o HUD

            puts("\n\n ________________");
            printf("|");

                textcolor(12);          //Muda os pr�ximos textos para a cor vermelha
           printf("--> COMANDOS <--");
                textcolor(15);          //Retorna os pr�ximos textos para a cor branca


            puts("|");
            puts("|________________|");
            puts("|                |");
            puts("| W  -  Cima     |");
            puts("| S  -  Baixo    |");
            printf("| F  -  Escolher ");


            printf("|\n");

            puts("|________________|");

    printf("\n_____________________________________________________________________");
    printf("\n_____________________________________________________________________");
}

// ------------------------------------------------------------------------------------------------------------//





// ----------------------------|| Menu SinglePlayer ||-----------------------------//

void singlePlayer(int lin){
char op[1];  //Servir� de Entrada de comando do usu�rio


                clrscr();
                titulo2(); //Chama  T�tulo 2 (que aparece sem delay)
                printf("\n");

                textcolor(12);
                    printf("                -----------> MENU <-----------\n\n                      ");
                textcolor(15);

                    printf("      ");
                if (lin==1){
                        textcolor(0);
                        textbackground(15);
                            printf("Nivel 1");
                        textcolor(15);
                        textbackground(0);
                }else
                    printf("Nivel 1");
                    printf("\n                            ");

                if (lin==2){
                        textcolor(0);
                        textbackground(15);
                            printf("Nivel 2");
                        textcolor(15);
                        textbackground(0);
                }else{
                    textcolor(7);
                        printf("Nivel 2");
                    textcolor(15);
                }
                printf("\n                            ");

                if (lin==3){
                        textcolor(0);
                        textbackground(15);
                            printf("Nivel 3");
                        textcolor(15);
                        textbackground(0);
                }else{
                    textcolor(7);
                        printf("Nivel 3");
                    textcolor(15);
                }
                printf("\n                            ");
                if (lin==4){
                        textcolor(0);
                        textbackground(15);
                            printf("Nivel 4");
                        textcolor(15);
                        textbackground(0);
                }else{
                    textcolor(7);
                        printf("Nivel 4");
                    textcolor(15);
                }
                printf("\n                            ");
                if (lin==5){
                        textcolor(0);
                        textbackground(15);
                            printf("Nivel 5");
                        textcolor(15);
                        textbackground(0);
                }else{
                    textcolor(7);
                        printf("Nivel 5");
                    textcolor(15);
                }
                printf("\n                            ");

                if (lin==6){
                        textcolor(0);
                        textbackground(15);
                            printf("Voltar");
                        textcolor(15);
                        textbackground(0);
                }else
                    printf("Voltar");
                    printf("\n                            ");


                if (lin==7){
                        textcolor(0);
                        textbackground(15);
                            printf("CUSTOM");
                        textcolor(15);
                        textbackground(0);
                }else{
                    textcolor(2);
                        printf("CUSTOM");
                    textcolor(15);
                }
                printf("\n                            ");


    hudOpc();

    do{

        op[0]=getch(); //Entrada de comando do usu�rio
        op[0] = toupper(op[0]); //Converte o algarismo coletado para Mai�sculo
            switch (op[0]){


                case 'W':  //Caso o usu�rio aperte 'W'
                    if(lin>1){  //Se a linha n�o estiver no  topo
                        lin--; //Sobe a linha
                            moverMenu();
                    }
                break;

                case 'S':  //Caso o usu�rio aperte 'S'
                    if(lin<7){  //Se a linha n�o estiver no local mais baixo
                        lin++; //Desce a linha
                        moverMenu();
                    }
                break;

                case 'F':  //Caso o usu�rio aperte 'F'

                        if (lin==1){ //Se a linha 2 estiver selecionada
                                escolherMenu();
                            clrscr();
                            main(310,"1""310"); //Chama a fun��o main... N�vel 1.... Pontos M�ximos = 310

                        }


                        if (lin==2){ //Se a linha 2 estiver selecionada
                                escolherMenu();
                            main(150,"2""150");//Chama a fun��o main... N�vel 2.... Pontos M�ximos = 150
                            clrscr();

                        }


                        if (lin==3){ //Se a linha 3 estiver selecionada
                                escolherMenu();
                            main(170,"3""170");//Chama a fun��o main... N�vel 3.... Pontos M�ximos = 170
                            clrscr();

                        }

                        if (lin==4){ //Se a linha 3 estiver selecionada
                                escolherMenu();
                            main(160,"4""160");//Chama a fun��o main... N�vel 4.... Pontos M�ximos = 160
                            clrscr();

                        }

                        if (lin==5){ //Se a linha 3 estiver selecionada
                                escolherMenu();
                            main(310,"5""310");//Chama a fun��o main... N�vel 5.... Pontos M�ximos = 310
                            clrscr();

                        }

                        if (lin==6){ //Se a linha 3 estiver selecionada
                                escolherMenu();
                            clrscr();
                            novoJogo(1); //Retorna ao menu "Novo Jogo" com a 1� Linha selecionada
                        }

                        if (lin==7){ //Se a linha 3 estiver selecionada
                                escolherMenu();
                            main(2,"6""310");/*Chama a fun��o main... N�vel 6 (Custom Level).... os pontos m�ximos n�o importam, pois
                                                                                                ser�o modificados por outra fun��o*/
                            clrscr();

                        }


                break;


                default:
                break;

            }

            singlePlayer(lin);
        }while(1==1); //Infinitamente... ou at� alguma quebra de looping

system("pause"); //Pausa o jogo... mas n�o ser� usado.... utilizei apenas durante o desenvolvimento

}

// -----------------------------------------------------------------------------//





// ----------------------------|| Fun��o de "pausa" ||-----------------------------//

void tempo(int valor){
   int c,d;

   for ( c = 1 ; c <= valor ; c++ )
       for ( d = 1 ; d <= valor ; d++ )
       {}


}

// -----------------------------------------------------------------------------//



// ----------------------------|| Desenhando o T�tulo Com timing ||-----------------------------//

void titulo(){


        //LETRA 'R'
    textcolor(12);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("\n");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#     ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("\n");
        printf("#");
        tempo(2000);
        printf("#     ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("\n");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("# \n");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#   ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#  \n");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#    ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("# ");
        tempo(2000);
        printf("\n#");
        tempo(2000);
        printf("#     ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);



                //LETRA 'E'
        gotoxy(12,1);
        textcolor(11);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);
            gotoxy(12,2);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
            gotoxy(12,3);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);

            gotoxy(12,4);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
            gotoxy(12,5);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
            gotoxy(12,6);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
            gotoxy(12,7);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);


            //LETRA 'S'
        textcolor(10);
        gotoxy(22,1);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(22,2);
        printf("#");
        tempo(2000);
        printf("#    ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(22,3);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(22,4);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(22,5);
        printf("      #");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(22,6);
        printf("#");
        tempo(2000);
        printf("#    ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(22,7);
        printf(" #");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);


            //LETRA 'T'
        textcolor(5);
        gotoxy(32,1);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(32,2);
        printf("   #");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(32,3);
        printf("   #");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(32,4);
        printf("   #");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(32,5);
        printf("   #");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(32,6);
        printf("   #");
        tempo(2000);
        printf("#\n");
        tempo(2000);
        gotoxy(32,7);
        printf("   #");
        tempo(2000);
        printf("#\n");
        tempo(2000);



                //LETRA 'A'
        textcolor(14);
        gotoxy(45,1);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(44,2);
        printf("#");
        tempo(2000);
        printf("# ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(43,3);
        printf("#");
        tempo(2000);
        printf("#   ");
        printf("#");
        tempo(2000);
        printf("#");
        gotoxy(42,4);
        printf("#");
        tempo(2000);
        printf("#     ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        gotoxy(42,5);
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#\n");
        gotoxy(42,6);
        printf("#");
        tempo(2000);
        printf("#     ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        gotoxy(42,7);
        printf("#");
        tempo(2000);
        printf("#     ");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");



            //N�MERO '1'
        textcolor(15);
        gotoxy(60,1);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(58,2);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(60,3);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(60,4);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(60,5);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(60,6);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        gotoxy(58,7);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
        printf("#");
        tempo(2000);
    printf("\n_____________________________________________________________________");
    printf("\n_____________________________________________________________________");

    textcolor(15); //Volta a cor para Branco

}

// -----------------------------------------------------------------------------//







// ----------------------------|| Mostra o T�tulo Instantaneamente  ||-----------------------------//

void titulo2(){



            // LETRA 'R'
        textcolor(12);
            printf("########\n##     ##\n##     ##\n######## \n##   ##  \n##    ##\n##     ##");



            // LETRA 'E'
        gotoxy(12,1);
        textcolor(11);
            printf("########");
        gotoxy(12,2);
            printf("##");
        gotoxy(12,3);
            printf("##");
        gotoxy(12,4);
            printf("######");
        gotoxy(12,5);
            printf("##");
        gotoxy(12,6);
            printf("##");
        gotoxy(12,7);
            printf("########");


            //LETRA 'S'
        gotoxy(22,1);
        textcolor(10);
            printf("######");
        gotoxy(22,2);
            printf("##    ##");
        gotoxy(22,3);
            printf("##");
        gotoxy(22,4);
            printf("######");
        gotoxy(22,5);
            printf("      ##");
        gotoxy(22,6);
            printf("##    ##");
        gotoxy(22,7);
            printf(" ###### ");




            //LETRA 'T'
        gotoxy(32,1);
        textcolor(5);
            printf("########");
        gotoxy(32,2);
            printf("   ##  ");
        gotoxy(32,3);
            printf("   ##  ");
        gotoxy(32,4);
            printf("   ##  ");
        gotoxy(32,5);
            printf("   ##  ");
        gotoxy(32,6);
            printf("   ##  ");
        gotoxy(32,7);
            printf("   ##  ");


            //LETRA 'T'
        gotoxy(42,1);
        textcolor(14);
            printf("   ###");
        gotoxy(42,2);
            printf("  ## ##  ");
        gotoxy(42,3);
            printf(" ##   ##  ");
        gotoxy(42,4);
            printf("##     ##  ");
        gotoxy(42,5);
            printf("#########");
        gotoxy(42,6);
            printf("##     ##  ");
        gotoxy(42,7);
            printf("##     ##  ");



            //N�MERO '1'
        gotoxy(58,1);
        textcolor(15);
            printf("  ##");
        gotoxy(58,2);
            printf("####");
        gotoxy(58,3);
            printf("  ##");
        gotoxy(58,4);
            printf("  ##");
        gotoxy(58,5);
            printf("  ##");
        gotoxy(58,6);
            printf("  ##");
        gotoxy(58,7);
            printf("######");




    printf("\n_____________________________________________________________________");
    printf("\n_____________________________________________________________________");

    textcolor(15); //Volta a cor para Branco
}

// -----------------------------------------------------------------------------//





// ------------------------------|| EASTER EGG  ||-------------------------------//

void easter(){


    clrscr();
    tempo(30000);
    printf("  Operating System not found ....\n  ");
    tempo(20000);
    printf("NT ");
    tempo(10000);
    printf("kernel");
    printf(" error 29A\n  ");
    tempo(25000);
    printf("HD servo tracks not found\n  ");
    tempo(25000);
    printf("PSU electrical fire detected\n  ");
    tempo(25000);
    printf("Erasing backups");
    tempo(20000);
    printf(".");
    tempo(20000);
    printf(".");
    tempo(20000);
    printf(".");
    tempo(20000);
    printf(".");
    tempo(20000);
    printf(".");
    tempo(30000);
    printf(" done!\n\n  ");
    tempo(30000);
    printf("Your death threat to the President of the USA has been sent ...\n\n  ");
    tempo(30000);
    printf("To negate the above, wire $1.000.000 to Microsoft Corporation within the\n  next six <6> hours ...\n\n\n  ");
    tempo(30000);


    textcolor(10);
    printf("W");
    tempo(4000);
    printf("E");
    tempo(4000);
    printf(" ");
    tempo(4000);
    printf("W");
    tempo(4000);
    printf("I");
    tempo(4000);
    printf("L");
    tempo(4000);
    printf("L");
    tempo(4000);
    printf(" ");
    tempo(4000);
    printf("K");
    tempo(4000);
    printf("N");
    tempo(4000);
    printf("O");
    tempo(4000);
    printf("W");
    tempo(4000);
    printf(" ");
    tempo(4000);

    textcolor (15);
    printf("i");
    tempo(4000);
    printf("f");
    tempo(4000);
    printf(" ");
    tempo(4000);
    printf("y");
    tempo(4000);
    printf("o");
    tempo(4000);
    printf("u");
    tempo(4000);
    printf(" ");
    tempo(4000);
    printf("j");
    tempo(4000);
    printf("u");
    tempo(4000);
    printf("s");
    tempo(4000);
    printf("t");
    tempo(4000);
    printf(" ");
    tempo(4000);
    printf("s");
    tempo(4000);
    printf("w");
    tempo(4000);
    printf("i");
    tempo(4000);
    printf("t");
    tempo(4000);
    printf("c");
    tempo(4000);
    printf("h");
    tempo(4000);
    printf(" ");
    tempo(4000);
    printf("t");
    tempo(4000);
    printf("o");
    tempo(4000);
    printf(" ");
    tempo(4000);

    textcolor (12);
    printf("L");
    tempo(10000);
    printf("I");
    tempo(10000);
    printf("N");
    tempo(10000);
    printf("U");
    tempo(10000);
    printf("X\n\n\n  ");
    tempo(30000);



            textcolor(14);
        printf("Pressione qualquer tecla para reiniciar o jogo... ");
            textcolor(15);
            getch();  //Recebe um caracter pelo teclado
        clrscr(); //Limpa a tela
        menu();  //Volta para o Menu
}



// -----------------------------------------------------------------------------//





























