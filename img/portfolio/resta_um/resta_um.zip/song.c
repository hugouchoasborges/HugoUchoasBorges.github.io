#include <stdio.h>    //Biblioteca Padr�o
#include <windows.h>  //Para poder usar a fun��o Beep() e Sleep()

#define C0 16.35
#define C1 32.70
#define C2 65.41
#define C3 130.81
#define C90 17.32
#define C91 34.65
#define C92 69.30
#define C93 138.59
#define D0 18.35
#define D1 36.71
#define D2 73.42
#define D3 146.83
#define D90 19.45
#define D91 38.89
#define D92 77.78
#define D93 155.56
#define E0 20.60
#define E1 41.20
#define E2 82.41
#define E3 164.81
#define F0 21.83
#define F1 43.65
#define F2 87.31
#define F3 174.61
#define F90 23.12
#define F91 46.25
#define F92 92.50
#define F93 185.00
#define G0 24.50
#define G1 49.00
#define G2 98.00
#define G3 196.00
#define G90 25.96
#define G91 51.91
#define G92 103.84
#define G93 207.65
#define A0 27.50
#define A1 55.00
#define A2 110.00
#define A3 220.00
#define A90 29.14
#define A91 58.27
#define A92 116.54
#define A93 233.08
#define B0 30.84
#define B1 61.74
#define B2 123.47
#define B3 246.94
#define C4 261.63
#define C5 523.25
#define C6 1046.50
#define C7 2083.00
#define C8 4186.01
#define C94 277.18
#define C95 554.37
#define C96 1108.73
#define C97 2217.46
#define C98 4434.92
#define D4 293.66
#define D5 587.33
#define D6 1174.66
#define D7 2349.32
#define D8 4698.64
#define D94 311.13
#define D95 622.25
#define D96 1244.51
#define D97 2489.02
#define D98 4978.03
#define E4 329.63
#define E5 659.26
#define E6 1318.51
#define E7 2637.02
#define F4 349.23
#define F5 698.46
#define F6 1396.91
#define F7 2793.83
#define F94 369.99
#define F95 739.99
#define F96 1479.98
#define F97 2959.96
#define G4 392.00
#define G5 783.99
#define G6 1567.98
#define G7 3135.96
#define G94 415.30
#define G95 830.61
#define G96 1661.22
#define G97 3322.44
#define A4 440.00
#define A5 880.00
#define A6 1760.00
#define A7 3520.00
#define A94 466.16
#define A95 932.33
#define A96 1864.66
#define A97 3729.31
#define B4 493.88
#define B5 987.77
#define B6 1975.53
#define B7 3951.07

 /* Acima est�o definidas as frequ�ncias de 8 oitavas de uma escala musical
  * .... PS: N�o fiz isso especialmente para o jogo, fiz para brincar sozinho, mas ser� �til aqui tamb�m :D  */








//-----------------//  M�sica para quando ganhar o jogo //---------------------------------//

musicaVitoria(){


            Beep(G3,120);
            Beep(C4,120);
            Beep(E4,120);
            Beep(G4,120);
            Beep(C5,120);
            Beep(E5,120);
            Beep(G5,400);
            Beep(E5,400);


            Beep(G93,120);
            Beep(C4,120);
            Beep(D94,120);
            Beep(G94,120);
            Beep(C5,120);
            Beep(D95,120);
            Beep(G95,400);
            Beep(D95,400);


            Beep(A93,120);
            Beep(D4,120);
            Beep(F4,120);
            Beep(A94,120);
            Beep(D5,120);
            Beep(F5,120);
            Beep(A95,400);
            Beep(A95,120);
            Beep(A95,120);
            Beep(A95,120);
            Beep(C6,700);

}

//----------------------------------------------------------------------------------------//





//-----------------//  Som para quando Comer uma Pe�a //---------------------------------//

void comerPeca(){

    Beep(C6,100);
    Beep(C6,100);


}

//----------------------------------------------------------------------------------------//




//-----------------//  Som para quando mover nos Menus //---------------------------------//

void moverMenu(){

    Beep(D4,100);

}

//----------------------------------------------------------------------------------------//




//-----------------//  Som para quando Abrir o jogo //---------------------------------//

void abrirJogo(){

    Beep(D95,120);
    Beep(D96,120);
    Beep(A95,120);
    Beep(G5,120);
    Beep(D96,120);
    Beep(A95,120);
    Beep(G5,250);

    Beep(E5,120);
    Beep(E6,120);
    Beep(B5,120);
    Beep(G95,120);
    Beep(E6,120);
    Beep(B5,120);
    Beep(G95,250);

    Beep(D95,120);
    Beep(D96,120);
    Beep(A95,120);
    Beep(G5,120);
    Beep(D96,120);
    Beep(A95,120);
    Beep(G5,250);

    Beep(G5,80);
    Beep(G95,80);
    Beep(A5,80);
    Beep(A5,80);
    Beep(A95,80);
    Beep(B5,80);
    Beep(B5,80);
    Beep(C6,80);
    Beep(C96,80);
    Beep(C96,80);
    Beep(D6,80);
    Beep(D96,500);




}

//----------------------------------------------------------------------------------------//



//-----------------//  M�sica para quando sair do jogo //---------------------------------//

void sairJogo(){

    Beep(C7,600);
    Beep(G6,500);
    Beep(E6,850);
    Beep(A6,450);
    Beep(B6,380);
    Beep(A6,400);
    Beep(G96,400);
    Beep(A96,380);
    Beep(G96,400);
    Beep(G6,200);
    Beep(F6,200);
    Beep(G6,1000);

}

//----------------------------------------------------------------------------------------//





//-----------------//  Som para quando Perder\desistir de um jogo //---------------------------------//

void perderJogo(){

    Beep(B6,350);
    Beep(F7,400);
    Beep(F7,280);
    Beep(F7,400);
    Beep(E7,400);
    Beep(D7,400);
    Beep(C7,300);
    Beep(E6,450);
    Beep(E6,300);
    Beep(C6,600);


}

//----------------------------------------------------------------------------------------//




//-----------------//  Som para quando escolher algo do menu //---------------------------------//

void escolherMenu(){

    Beep(E6,350);

}

//----------------------------------------------------------------------------------------//























