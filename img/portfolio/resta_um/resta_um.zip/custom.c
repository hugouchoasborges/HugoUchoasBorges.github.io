
/**
  * Joguinho RESTA 1
  * Feito por "Hugo Uch�as Borges - n�-27106 - ECO Unifei" ... favor n�o piratear ;)
  */

#include<stdio.h> //Biblioteca Padrao



//--------------------------------|| N�vel Custom ||--------------------------------------//

void nivelCustom(char m[7][7]){
    int i,j,lin=3,col=3;
    char visual[7][7];


        for(i=0;i<7;i++){
            for(j=0;j<7;j++){
                m[i][j]=' '; //Todos os elementos da matriz recebem ' ', que futuramente ser�o "vazios"... ou seja, sem pe�a
            }
        }



    clrscr();
    inicializaVisual(visual);   //Inicializa a Matriz Visual, que ser� apresentada ao Jogador
    atualizaVisual(m,visual);     // Chama a fun��o atualizaVisual, tendo a matriz "tab" e a matriz "visual" como par�metros
    imprimeVisualCustom(visual,lin,col); //Imprime a Matriz VisualCustom  (uma matriz pr�pria para o Level Creator)
    hudCustom(); //Chama o HUD Criado especificamente para o "Level Creator"
    controles(m,visual,lin,col); // Fun��o que controla os comandos do usu�rio, criei apenas para melhor organiza��o, podia colocar seus comandos aqui mesmo

}

//---------------------------------------------------------------------------------------------------------//




//------------------------------|| HUD (LEVEL CREATOR) ||--------------------------------------------------//

void hudCustom(){


                gotoxy(1,10); //move o cursor para debaixo do Tabuleiro, onde ser� impresso o HUD

            puts("\n\n ________________");
            printf("|");

                textcolor(12);          //Muda os pr�ximos textos para a cor vermelha
           printf("--> COMANDOS <--");
                textcolor(15);          //Retorna os pr�ximos textos para a cor branca


            puts("|");
            puts("|________________|");
            puts("|                |");
            puts("| W  -  Cima     |");
            puts("| S  -  Baixo    |");
            puts("| A  -  Esquerda |");
            puts("| D  -  Direita  |");
            puts("| C  -  Colocar  |");
            puts("| R  -  Retirar  |");
            puts("| X  -  Sair     |");

            puts("|________________|");
}

//----------------------------------------------------------------------------------------//






// ------------------------------|| Imprimindo a Matriz Visual ||--------------------------//

void imprimeVisualCustom(char m[7][7],int lin,int col){
    int i,j,h;


            printf("             |");

            textbackground(15); //Muda a cor do fundo para branco
            textcolor(0); //Muda a cor do texto para preto

                        printf("       ------| RESTA 1 |------    "); //T�tulo do jogo

            textcolor(15); // Volta o texto para a cor Branca
            textbackground(0);  // Volta o fundo para a  cor preta




    printf("|\n             |                                  |\n             |    ");


        for (i=0;i<7;i++){
            for (j=0;j<7;j++){
                    if ((i>=0&&i<2)&&(j==0||j==1||j==6||j==5) || (i<7&&i>4)&&(j==0||j==1||j==6||j==5)){ /*Exce��o que distingue os cantos in�teis do
                                                                                                         *tabuleiro de seu centro na matriz */
                        m[i][j]=' ';   /*Todos os elementos da Matriz que n�o pertencem ao
                                        * tabuleiro receber�o ' ' como valor */
                            printf(" %c  ",m[i][j]);
                    }else
                        printf("[%c] ",m[i][j]); // Coloca os valores do tabuleiro entre colchetes, para melhor representa��o

            }
            printf("  |\n             |    ");
        }
        delline(); //Deleta a linha atual
        gotoxy(1,10); //Manda o cursor para a coluna 1 da linha 0
        printf("             |");
            textcolor(2);
                    printf("CUSTOM");
            textcolor(15);
                    printf("____________________________|");




                textcolor(12);
                        gotoxy(19+((col*4)),3+lin); //Posiciona o cursor no primeiro colchete de alguma posi��o do tabuleiro
                            printf("[");  //Substitui o abre-colchete atual por um outro COLORIDO
                        gotoxy(21+((col*4)),3+lin); //Posiciona o cursor no segundo colchete de alguma posi��o do tabuleiro
                            printf("]"); //Substitui o fecha-colchete atual por um outro COLORIDO

                textcolor(15);     // Muda a cor do texto de volta para Branco

                        // Aqui em cima eu basicamente pintei os colchetes da posi��o onde o cursor estiver



}

//--------------------------------------------------------------------------------------------------------------------//



void controles(char tab[7][7],char visual[7][7], int lin, int col){
    int i,j;
    char o[1];        //Entrada de comando do jogador;
    char com[1];     //Entrada de comando do jogador;
    int bomb=0;      /*� um contador de bombas colocadas, ser� �til para a programa��o, mas nem tanto para o usu�rio
                      * Servir� futuramente pra calcular a pontua��o m�xima do n�vel criado....*/

        for (i=0;i<7;i++){
                for (j=0;j<7;j++){
                    if (tab[i][j]==50)
                        bomb++; //Toda vez que controles() for chamado, isso contar� quantas bombas existem no jogo...
                }
            }

    do{
        gotoxy(20,13); // Move o cursor para o lado do HUD

                printf("Pecinhas Colocadas: %d",bomb);

        com[0]=getch();  //Captura os comandos do jogador
        com[0] = toupper(com[0]); //Converte algarismo para Mai�sculo



                switch(com[0]){

                    case 'D':           // Caso o jogador aperte 'd'
                        if ((col<6)&&(lin==2||lin==3||lin==4) || (col<4)&&(lin==0||lin==1||lin==5||lin==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite DIREITO do tabuleiro */
                            col++;  // A coluna selecionada se desloca para a DIREITA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisualCustom(visual,lin,col);
                                        hudCustom();
                        }
                    break;



                    case 'A':           // Caso o jogador aperte 'a'
                        if ((col>0)&&(lin==2||lin==3||lin==4) || (col>2)&&(lin==0||lin==1||lin==5||lin==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite ESQUERDO do tabuleiro*/
                            col--;  // A coluna selecionada se desloca para a ESQUERDA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisualCustom(visual,lin,col);
                                        hudCustom();

                        }
                    break;



                    case 'W':           // Caso o jogador aperte 'w'
                        if ((lin>0)&&(col==2||col==3||col==4) || (lin>2)&&(col==0||col==1||col==5||col==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite MAIS ALTO do tabuleiro*/
                            lin--;  // A linha selecionada se desloca para CIMA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisualCustom(visual,lin,col);
                                        hudCustom();
                        }
                    break;



                    case 'S':           // Caso o jogador aperte 's'
                        if ((lin<6)&&(col==2||col==3||col==4) || (lin<4)&&(col==0||col==1||col==5||col==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite MAIS BAIXO do tabuleiro*/
                            lin++;  // A linha selecionada se desloca para BAIXO
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisualCustom(visual,lin,col);
                                        hudCustom();
                        }
                    break;


                    case 'C': //Caso o jogador aperte 'C'

                        tab[lin][col]=50; //Coloca o n�mero '2' no Local, que representa uma bomba
                        clrscr();
                        atualizaVisual(tab,visual);
                        imprimeVisualCustom(visual,lin,col);
                        hudCustom();
                        controles(tab,visual,lin,col);


                    break;



                    case 'R': //Caso o jogador aperte 'R'

                        tab[lin][col]=49; //Coloca o n�mero '1' no Local, que representa um espa�o vazio
                        clrscr();
                        atualizaVisual(tab,visual);
                        imprimeVisualCustom(visual,lin,col);
                        hudCustom();
                        controles(tab,visual,lin,col);

                    break;




                    case 'X': //Caso o jogador aperte 'x'
                        do{
                                    gotoxy(20,14);

                                    printf("Deseja: Sair(1) || Voltar para o Menu(2) || Jogar(3) ");
                                        o[0]=getch(); //Captura de tecla do jogador

                                                switch(o[0]){
                                                    case '1': //Caso aperte 1
                                                        gotoxy(20,25);
                                                        exit(0); //Sai do jogo
                                                    break;

                                                    case '2': //Caso aperte 2
                                                        clrscr();
                                                         menu(); //Volta para o Menu Principal
                                                    break;

                                                    case '3': //Caso aperte 3
                                                        if (bomb==0){
                                                            gotoxy(20,14);
                                                            printf("                                                    "); //Apaga o Texto na posi��o (14,20)
                                                            gotoxy(20,14);
                                                            printf("Voce deve colocar ao menos 1 bomba para poder jogar");
                                                            gotoxy(20,16);
                                                            printf("Aperte qualquer tecla para voltar ao jogo...");
                                                            getch(); //Entrada de caracter pelo usu�rio
                                                            gotoxy(20,14);
                                                            printf("                                                        "); //Apaga o Texto na posi��o (14,20)
                                                            gotoxy(20,16);
                                                            printf("                                                 "); //Apaga o Texto na posi��o (14,20)
                                                            controles(tab,visual,lin,col);
                                                        }else if (bomb==33){
                                                            gotoxy(20,14);
                                                            printf("                                                    "); //Apaga o Texto na posi��o (14,20)
                                                            gotoxy(20,14);
                                                            printf("Voce deve deixar ao menos 1 lugar vazio para poder jogar");
                                                            gotoxy(20,16);
                                                            printf("Aperte qualquer tecla para voltar ao jogo...");
                                                            getch(); //Entrada de caracter pelo usu�rio
                                                            gotoxy(20,14);
                                                            printf("                                                        "); //Apaga o Texto na posi��o (14,20)
                                                            gotoxy(20,16);
                                                            printf("                                                 "); //Apaga o Texto na posi��o (14,20)
                                                            controles(tab,visual,lin,col);
                                                        }else{
                                                            clrscr();
                                                            for(i=0;i<7;i++){
                                                                for(j=0;j<7;j++){
                                                                    printf("%c",tab[i][j]);
                                                                }
                                                                printf("\n");
                                                            }
                                                            i=(bomb-1)*10; //Definindo Pontua��o M�xima da fase

                                                            main2(i,tab);/*Chama a fun��o main2... N�vel 7 (Custom Level)....
                                                                             * i --> � a pontua��o m�xima desse mapa,
                                                                             uso isso para saber quando o usu�rio ganhou o jogo*/


                                                        }

                                                    break;

                                                    default:
                                                        gotoxy(20,14);
                                                        printf("                                                 ");//Apaga o Texto na posi��o (14,20)
                                                    break;
                                                    }
                        }while(1==1); //Sempre se repetir�, a menos que algo quebre o looping
                    break;

                    default: //QUando qualquer outro bot�o for apertado
                    break;


                }
    }while(1==1);//Sempre se repetir�, a menos que alguma fun��o quebre o looping

}







//--------------------------------------|| Main 2 ||----------------------------------------------------------//

void main2(int argc,char m[7][7]){   //Esse segundo Main foi criado especialmente para o Custom Level

            int pntmax;
            int i,j,cont=0;
            char o[1];
            char tab[7][7],nivel='7';
            char visual[7][7];
            int sel=0,lin=3,col=3,lin2,col2;
            int pnt=0;
            char com[1];

            clrscr();
            pntmax=argc; //Argc define a pontua��o m�xima do jogo

                for(i=0;i<7;i++){
                        for(j=0;j<7;j++){
                            tab[i][j]=m[i][j];
                                if(tab[i][j]==' ')
                                    tab[i][j]=49;

                        }

                }

            clrscr();

        inicializaVisual(visual);       // Chama a fun��o inicializaVisual, tendo a matriz "visual" como par�metro
        atualizaVisual(tab,visual);     // Chama a fun��o atualizaVisual, tendo a matriz "tab" e a matriz "visual" como par�metros
        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);  // Chama a fun��o imprimeVisual, tendo a matriz "visual", e os inteiros "lin" , "col" e "sel" como par�metros
        hud(sel);                       //Chama a fun��o Hud... tendo o inteiro "sel" como par�metro


    do{
            if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o respectivo n�vel
            goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2


        gotoxy(20,13); // Move o cursor para o lado do HUD
            printf("Pontuacao: %d Pontos",pnt);

            verificaJogo(visual); //Verifica se existem jogadas possiveis



        com[0]=getch();  //Captura os comandos do jogador
        com[0] = toupper(com[0]); //Converte algarismo para Mai�sculo

                switch(com[0]){

                    case 'D':           // Caso o jogador aperte 'd'
                        if ((col<6)&&(lin==2||lin==3||lin==4) || (col<4)&&(lin==0||lin==1||lin==5||lin==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite DIREITO do tabuleiro */
                            col++;  // A coluna selecionada se desloca para a DIREITA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);


                        }
                    break;



                    case 'A':           // Caso o jogador aperte 'a'
                        if ((col>0)&&(lin==2||lin==3||lin==4) || (col>2)&&(lin==0||lin==1||lin==5||lin==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite ESQUERDO do tabuleiro*/
                            col--;  // A coluna selecionada se desloca para a ESQUERDA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                        }
                    break;



                    case 'W':           // Caso o jogador aperte 'w'
                        if ((lin>0)&&(col==2||col==3||col==4) || (lin>2)&&(col==0||col==1||col==5||col==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite MAIS ALTO do tabuleiro*/
                            lin--;  // A linha selecionada se desloca para CIMA
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                        }
                    break;



                    case 'S':           // Caso o jogador aperte 's'
                        if ((lin<6)&&(col==2||col==3||col==4) || (lin<4)&&(col==0||col==1||col==5||col==6)){ /* se o jogador n�o estiver
                                                                                                              * no limite MAIS BAIXO do tabuleiro*/
                            lin++;  // A linha selecionada se desloca para BAIXO
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                        }
                    break;


                    case 'F': //Caso o jogador aperte 'f'

                       if (sel==0){ //Se o jogador n�o estiver segurando a pe�a

                            if (visual[lin][col]=='o'){ // E se a posi��o no tabuleiro estiver ocupada

                                sel=1; // O jogador passa a segurar a pe�a
                                    lin2=lin;  //a posi��o "lin" ser� marcada na vari�vel "lin2" ... para uso posterior
                                    col2=col;  //a posi��o "col" ser� marcada na vari�vel "col2" ... para uso posterior
                                clrscr(); // Limpa a Tela

                                        atualizaVisual(tab,visual);
                                        imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                        hud(sel);

                            }

                       }

                       else{  // Ou seja,  se o jogador estiver segurando a Pe�a

                                if (visual[lin][col]=='o'){     //Se a posi��o no tabuleiro estiver ocupada

                                    sel=0; // O jogador Solta a pe�a  - N�O MUDANDO NADA NO JOGO;
                                    clrscr(); // Limpa a Tela

                                            atualizaVisual(tab,visual);
                                            imprimeVisual(visual,lin,col,sel,lin2,col2,nivel);
                                            hud(sel);

                                }


                                if (visual[lin][col]==' '){ // Se a posi��o no tabuleiro estiver Vazia

                                       if ((col==col2)&&((lin2==(lin)-2))&&(visual[lin-1][col]=='o')){ /* Se a coluna de onde a pe�a for retirada for
                                                                            * igual � coluna onde o usu�rio est� tentando colocar a pe�a.
                                                                            * E se a linha retirada for duas posi��es ACIMA de onde
                                                                            * o usu�rio est� tentando coloc�-la.
                                                                            * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                            sel=0; // O usu�rio soltar� a pe�a;
                                            comerPeca(); //Som para comer pe�as

                                            tab[lin-2][col]=49;  // A coluna onde a pe�a estava ficar� vazia
                                            tab[lin-1][col]=49; //A coluna entre as duas ficar� vazia
                                            tab[lin][col]=50; //A coluna de destino receber� uma pe�a.

                                                pnt+=10; // O usu�rio ganhar� 10 pontos
                                                    if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                    goto FIM2;       //respectivel n�vel , finalize o jogo com o Final 2*/


                                        }


                                        if ((col==col2)&&((lin2==(lin)+2))&&(visual[lin+1][col]=='o')){ /* Se a coluna de onde a pe�a for retirada for
                                                                            * igual � coluna onde o usu�rio est� tentando colocar a pe�a.
                                                                            * E se a linha retirada for duas posi��es ABAIXO de onde
                                                                            * o usu�rio est� tentando coloc�-la.
                                                                            * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                            sel=0; // O usu�rio soltar� a pe�a;
                                            comerPeca(); //Som para comer pe�as

                                            tab[lin+2][col]=49;  // A coluna onde a pe�a estava ficar� vazia
                                            tab[lin+1][col]=49; //A coluna entre as duas ficar� vazia
                                            tab[lin][col]=50; //A coluna de destino receber� uma pe�a.


                                                pnt+=10; // O usu�rio ganhar� 10 pontos
                                                if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                        goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2


                                        }


                                        if ((lin==lin2)&&((col2==(col)+2))&&(visual[lin][col+1]=='o')){ /* Se a linha de onde a pe�a for retirada for
                                                                            * igual � linha onde o usu�rio est� tentando colocar a pe�a.
                                                                            * E se a coluna retirada for duas posi��es � DIREITA de onde
                                                                            * o usu�rio est� tentando coloc�-la.
                                                                            * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                            sel=0; // O usu�rio soltar� a pe�a;
                                            comerPeca(); //Som para comer pe�as

                                            tab[lin][col+2]=49;  // A coluna onde a pe�a estava ficar� vazia
                                            tab[lin][col+1]=49; //A coluna entre as duas ficar� vazia
                                            tab[lin][col]=50; //A coluna de destino receber� uma pe�a.


                                                pnt+=10; // O usu�rio ganhar� 10 pontos
                                                if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                        goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2*/


                                        }


                                        if ((lin==lin2)&&((col2==(col)-2))&&(visual[lin][col-1]=='o')){ /* Se a linha de onde a pe�a for retirada for
                                                                            * igual � linha onde o usu�rio est� tentando colocar a pe�a.
                                                                            * E se a coluna retirada for duas posi��es � ESQUERDA de onde
                                                                            * o usu�rio est� tentando coloc�-la.
                                                                            * E se a posi��o entre as duas mencionadas estiver cheia, ent�o: */

                                            sel=0; // O usu�rio soltar� a pe�a;
                                            comerPeca(); //Som para comer pe�as

                                            tab[lin][col-2]=49;  // A coluna onde a pe�a estava ficar� vazia
                                            tab[lin][col-1]=49; //A coluna entre as duas ficar� vazia
                                            tab[lin][col]=50; //A coluna de destino receber� uma pe�a.


                                                pnt+=10; // O usu�rio ganhar� 10 pontos
                                                if (pnt==pntmax) //Se o jogador tiver a pontua��o m�xima para o
                                                        goto FIM2; //respectivel n�vel , finalize o jogo com o Final 2*/


                                        }

                                    clrscr(); // Limpa a Tela

                                            atualizaVisual(tab,visual);
                                            imprimeVisual(visual,lin,col,sel,lin2,col2,imprimeVisual);
                                            hud(sel);

                                }
                       }

                    break;




                    case 'X': //Caso o jogador aperte 'x'
                        do{
                                    gotoxy(20,14);
                                    printf("                                                                            ");
                                    gotoxy(20,14);
                                    printf("Deseja: Sair(1) || Voltar para o Menu(2) ");
                                        o[0]=getch();
                                                switch(o[0]){
                                                    case '1':
                                                        gotoxy(20,25);
                                                        goto FIM; //Sai do jogo
                                                    break;

                                                    case '2':
                                                        clrscr();
                                                         menu(); //Volta para o Menu Principal
                                                    break;

                                                    default:
                                                        gotoxy(20,14);
                                                        printf("                                                 ");
                                                    break;
                                                    }
                        }while(1==1); //Sempre se repetir�, a menos que alguma fun��o quebre o looping
                    break;

                    default: //Qualquer outro bot�o apertado
                    break;


                }
    }while(1==1);



    FIM: //Finaliza��o do jogo caso o usu�rio DESISTA DA PARTIDA
        gotoxy(1,23);
            textcolor(12);
                printf("                       FIM DE JOGO\n");
            textcolor(2);
                printf("                     Voce fez:");
            textcolor(15);
                printf(" %d Pontos",pnt);

        gotoxy(1,25); //Simplesmente coloca o "process returned...." no final do programa

    puts("\n");
    sairJogo(); //M�sica quando o jogador desiste de uma partida
    system("pause");

    exit(0); //Encerra o jogo



FIM2://Finaliza��o do jogo caso o usu�rio VEN�A A PARTIDA
    clrscr(); // Limpa a Tela
    atualizaVisual(tab,visual);
    imprimeVisual(visual,lin,col,sel,lin2,col2,visual);
    hud(sel);


    gotoxy(1,23);
            textcolor(13);
                printf("                       FIM DE JOGO\n");
            textcolor(2);
                printf("             Voce fez:");
            textcolor(15);
                printf(" %d Pontos .... PONTUACAO MAXIMA",pnt);

                    musicaVitoria(); //M�sica tocada quando o jogador vence

        gotoxy(1,25); //Simplesmente coloca o "process returned...." no final do programa

    puts("\n");
    system("pause");
    clrscr();
    menu();


}














